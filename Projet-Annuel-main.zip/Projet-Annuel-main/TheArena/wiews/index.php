<?php require '../core/header.php' ?>
            <div class="row my-3">
                <div class="col my-3"> <!--Caroussel-->
                    <img style="position: relative; left:0; width:500px; height:200px;" src="#">
                </div>
            </div>
            <div class="row my-3">
                <div class="col my-3 d-flex flex-wrap title">
                    <h2><strong><u>Événements à l'affiche :</u></strong></h2> <!-- 2ème truc qui slide-->
                </div>
            </div>
            <div class="row my-3">
                <div class="col my-3 d-flex justify-content-around">
                    <img style="position: relative; left:0; width:200px; height:200px;" src="#">
                    <img style="position: relative; left:0; width:200px; height:200px;" src="#">
                </div>
            </div>


<?php require '../core/footer.php' ?>