<?php require '../core/header.php' ?>

        <div class="col-9 my-3 py-4 d-flex align-content-center flex-column flex-wrap">
            <div class="row my-3">
                <h2><u>Evenement<u></h2>
            </div>
            <div class="row my-3">
                <div class="col"> 
                    <a href="evenement2.php"><img style="position: relative; left:0; width: 250px; height:250px;" src="../img/evenement1.jpg" ></a>
                </div>
                <div class="col"> 
                    <img style="position: relative; left:0; width: 250px; height:250px;" src="#">
                </div>
                <div class="col"> 
                    <img style="position: relative; left:0; width: 250px; height:250px;" src="#">
                </div>
            </div>
        <div class="row my-3">
            <div class="col"> 
                    <img style="position: relative; left:0; width: 250px; height:250px;" src="#" href="#">
                </div>
                <div class="col"> 
                    <img style="position: relative; left:0; width: 250px; height:250px;" src="#">
                </div>
                <div class="col"> 
                    <img style="position: relative; left:0; width: 250px; height:250px;" src="#">
                </div>
            </div>
            <div class="col">
                <nav aria-label="Page navigation example" class="d-flex justify-content-center">
                    <ul class="pagination">
                        <li class="page-item"><a class="page-link" href="#">Previous</a></li>
                        <li class="page-item"><a class="page-link" href="#">1</a></li>
                        <li class="page-item"><a class="page-link" href="#">2</a></li>
                        <li class="page-item"><a class="page-link" href="#">3</a></li>
                        <li class="page-item"><a class="page-link" href="#">Next</a></li>
                    </ul>
                </nav>
            </div>
        </div>

        <div class="row my-3">
            <div>
                <a>
            </div>
        </div>
<?php require '../core/footer.php' ?>