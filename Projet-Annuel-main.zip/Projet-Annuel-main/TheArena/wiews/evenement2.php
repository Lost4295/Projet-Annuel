<?php require '../core/header.php' ?>
    <div class="row col-12">
        <nav class="navbar bar">
            <a class="btn btn-primary active btn-warning" href="evenement2.php">Accueil</a>
            <a class="navbarSecondaryBtn" href="participant.php">Participants</a>
            <a class="navbarSecondaryBtn" href="dashboard.php">Tableau de bord</a>
            <a class="navbarSecondaryBtn " href="shop.php">Shop</a>
        </nav>
    </div>    
    <div class="row">
        <h2><u>Evenement<u></h2>
    </div>   
    <div class="row">
        <img style="position: relative; left: 300px; width: 685px; height: 279px;" src="../img/evenement1.jpg">
    </div>
    <div class="row col-3">
        <h4>Informations</h4>
    </div>
    <div class="row">
        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Harum provident dolor, quam maxime nostrum debitis vitae voluptatum velit nobis quae ea magni illum cupiditate, perferendis numquam iste laborum nam reiciendis!</p>
    </div>
    <div class="col-12 d-flex align-content-center flex-column flex-wrap">
        <a class="btn btn-primary  btn-warning" href="inscriptionEvenement.php">S'inscrire</a>
    </div>
<?php require '../core/footer.php' ?>