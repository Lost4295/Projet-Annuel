<?php require '../core/header.php' ?>  
    <div class="row col-12">
        <nav class="navbar bar">
            <a class="navbarSecondaryBtn" href="evenement2.php">Accueil</a>
            <a class="navbarSecondaryBtn" href="participant.php">Participants</a>
            <a class="btn btn-primary active btn-warning" href="tableauBord.php">Tableau de bord</a>
            <a class="navbarSecondaryBtn " href="shop.php">Shop</a>
        </nav>
    </div> 
    <div class="row">
        <h2><u>Tableau de bord<u></h2>
    </div>
    <div class="row border">
        <div class="d-flex align-content-center flex-column flex-wrap">
            contre
        </div>
        <div class="row">
            <div class="col-4 d-flex align-content-center flex-column flex-wrap">
                participant 1 
            </div>       
            <div class="col-4 d-flex align-content-center flex-column flex-wrap">
                <h4>1 - 0</h4>
            </div>    
            <div class="col-4 d-flex align-content-center flex-column flex-wrap">
                participant 2
            </div>
        </div>
    </div>

    <div class="col-12 d-flex align-content-center flex-column flex-wrap">
        <a class="btn btn-primary  btn-warning" href="#">inscrire les score</a>
    </div>
    <div class="row">
        <div class="border col-6 d-flex align-content-center flex-column flex-wrap">
            info
        </div>
        <div class="border col-6 d-flex align-content-center flex-column flex-wrap  ">
            info
        </div>
    </div>

<?php require '../core/footer.php' ?>