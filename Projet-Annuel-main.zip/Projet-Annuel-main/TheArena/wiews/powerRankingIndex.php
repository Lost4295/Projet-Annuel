<?php require '../core/header.php' ?>
    <div class="row border">
        <h2>Classement Counter Strike : Global Offensive  par équipes</h2>
    </div>
    <div class="row border">
    <nav class="navbar navbar-expand-lg navbarBorder  ">
    <div class="container-fluid d-flex justify-content-center">
      <ul class="navbar-nav">
        <li class="nav-item border">
          <a class="nav-link active" aria-current="page" href="#">CSGO</a>
        </li>
        <li class="nav-item border">
          <a class="nav-link active" aria-current="page" href="#">LOL</a>
        </li>
        <li class="nav-item border">
          <a class="nav-link" href="#">Smash</a>
        </li>
        <li class="nav-item border">
          <a class="nav-link" href="#">SC2</a>
        </li>
        <li class="nav-item border">
          <a class="nav-link" href="#">R6</a>
        </li>
        <li class="nav-item border">
          <a class="nav-link" href="#">Rocket League </a>
        </li>
      </ul>
      
    </div>

    </nav>
    </div>
        <div class="row d-flex justify-content-center">
            <div class="container-fluid">
                <form class="d-flex">
                    <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                    <button class="btn btn-outline-success" type="submit">Search</button>
                </form>
            </div>
    </div>
    <div class="row d-flex justify-content-center border col-12">
            <img style="position: relative; left:0; width: 15px; height:15px;" src="../core/img/evenement1.jpg">
        <div class="row d-flex justify-content-center"> 
            <h4>Falcons</h4>
        </div>
            
    </div>
<?php require '../core/footer.php' ?>