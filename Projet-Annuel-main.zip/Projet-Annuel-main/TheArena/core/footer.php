</div>
</div>
</div>
<footer class="footer bar py-4">
    <div class="d-flex justify-content-between">
    <img src="logothearena-removebg.png" alt="Logo"  class="d-inline-block align-text-center logo">
    <div>
    <button class="btn btn-warning messages">Messagerie</button>
    </div>
    </div>
    <p class="text-center text-muted">&copy; <?php echo date("Y");?> - Ylan Turin--Kondi, Esteban Bonnard, Zacharie Roger</p>
</footer>
</div>
</body>
</html>