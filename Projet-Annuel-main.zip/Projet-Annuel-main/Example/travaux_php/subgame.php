

<!DOCTYPE HTML>
<html>
    <head>
        <meta name="Page" content="Quelle page magnifique">
        <meta charset="UTF-8">
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
        <div>
            <table>
                <a class=' btn btn-primary' href='index.php'> index </a><br><br><!--  // à prendre à chaque fois -->
                <a class=' btn btn-primary' href='register.php'> register (game) </a><br><br>
                <!-- <a class=' btn btn-primary' href='game.php'>  Game (ne pas aller)  </a><br><br> -->
            </table> 
        </div>
    </body>
</html>