<?php require 'header.php'; ?>
<div class="container-fluid">
        <div class="btn-group">
            <a class=' btn btn-primary btn-lg ' href='connexion.php'> connexion (compte)</a>
            <a class=' btn btn-primary btn-lg ' href='register.php'> Inscription (compte) </a>
        </div>


        <?php require 'footer.php' ?>