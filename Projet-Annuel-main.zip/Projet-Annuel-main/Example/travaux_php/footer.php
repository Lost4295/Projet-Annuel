<footer class="footer py-3 my-4 mx-0">
    <p class="text-center text-muted">&copy; <?php echo date("Y");?> - Ylan Turin--Kondi, Esteban Bonnard, Zacharie Roger</p>
</footer>
</div>
</body>
</html>